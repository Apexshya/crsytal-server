const cloudinary = require('cloudinary').v2;
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_PUBLISHABLE_KEY,
  api_secret: process.env.CLOUDINARY_SECRET_KEY,
  secure: true,
});

module.exports = cloudinary;
